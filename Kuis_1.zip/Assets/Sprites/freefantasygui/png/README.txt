- To separate the image, use this tool: http://renderhjs.net/shoebox/

- Just in case the tool failed to extract the sprites, usually it's because the image resolution is too big, then resize the image using this tool first: http://www.highmotionsoftware.com/products/imbatch

- Both FREE